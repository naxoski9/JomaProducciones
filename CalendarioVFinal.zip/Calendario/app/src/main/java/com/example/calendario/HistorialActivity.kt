

package com.example.calendario

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.firestore.FirebaseFirestore

class HistorialActivity : AppCompatActivity() {

    private lateinit var baseDatos: FirebaseFirestore
    private lateinit var recyclerView: RecyclerView
    private lateinit var historialAdapter: HistorialAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_historial)

        baseDatos = FirebaseFirestore.getInstance()
        recyclerView = findViewById(R.id.recyclerViewHistorial)
        recyclerView.layoutManager = LinearLayoutManager(this)

        historialAdapter = HistorialAdapter(mutableListOf())
        recyclerView.adapter = historialAdapter

        cargarHistorial()
    }

    private fun cargarHistorial() {
        baseDatos.collection("Historial_Eventos").get()
            .addOnSuccessListener { documentos ->
                val listaHistorial = mutableListOf<Evento>()
                for (documento in documentos) {
                    val nombreEvento = documento.getString("nombre") ?: "Sin nombre"
                    val notaEvento = documento.getString("nota") ?: "Sin nota"
                    val fecha = documento.getString("fecha") ?: "Sin fecha"

                    listaHistorial.add(Evento(nombreEvento, notaEvento, fecha))
                }
                historialAdapter.actualizarEventos(listaHistorial)
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error al cargar historial: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }
}
