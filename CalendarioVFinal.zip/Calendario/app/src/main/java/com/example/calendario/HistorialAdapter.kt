package com.example.calendario

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class HistorialAdapter(private var eventos: MutableList<Evento>) : RecyclerView.Adapter<HistorialAdapter.HistorialViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): HistorialViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_evento, parent, false)
        return HistorialViewHolder(view)
    }

    override fun onBindViewHolder(holder: HistorialViewHolder, position: Int) {
        val evento = eventos[position]
        holder.nombreEvento.text = evento.nombre
        holder.notaEvento.text = evento.nota
        holder.fechaEvento.text = evento.fecha
    }

    override fun getItemCount(): Int = eventos.size

    fun actualizarEventos(nuevosEventos: List<Evento>) {
        eventos.clear()
        eventos.addAll(nuevosEventos)
        notifyDataSetChanged()
    }

    class HistorialViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        val nombreEvento: TextView = itemView.findViewById(R.id.tvNombreEvento)
        val notaEvento: TextView = itemView.findViewById(R.id.tvNotaEvento)
        val fechaEvento: TextView = itemView.findViewById(R.id.tvFechaEvento)
    }
}
