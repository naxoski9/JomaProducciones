package com.example.calendario

data class Evento(val nombre: String, val nota: String, val fecha: String)