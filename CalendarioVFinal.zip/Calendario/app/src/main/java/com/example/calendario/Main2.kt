package com.example.calendario

import android.app.AlertDialog
import android.app.DatePickerDialog
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.firestore.FirebaseFirestore
import java.util.*

class Main2 : AppCompatActivity() {

    private val db = FirebaseFirestore.getInstance()

    // Mapas para CheckBox y TextView
    private lateinit var checkboxMap: Map<String, CheckBox>
    private lateinit var fechaTextViewMap: Map<String, TextView>

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.main2)

        // Inicializar mapas de referencias
        checkboxMap = mapOf(
            "Cabina Fotográfica" to findViewById(R.id.checkbox_cabina_fotografica),
            "Luces LED" to findViewById(R.id.checkbox_luces),
            "Proyector" to findViewById(R.id.checkbox_proyector),
            "Sistema de Audio" to findViewById(R.id.checkbox_audio)
        )

        fechaTextViewMap = mapOf(
            "Cabina Fotográfica" to findViewById(R.id.tvFechaCabina),
            "Luces LED" to findViewById(R.id.tvFechaLuces),
            "Proyector" to findViewById(R.id.tvFechaProyector),
            "Sistema de Audio" to findViewById(R.id.tvFechaAudio)
        )

        cargarEstados()

        // Configurar botones
        findViewById<Button>(R.id.btnVolverAtras).setOnClickListener { finish() }
        findViewById<Button>(R.id.btnMantenimientoImplementos).setOnClickListener { mostrarDialogoMantenimiento() }
        findViewById<Button>(R.id.btnReservarImplementos).setOnClickListener { mostrarDialogoReservar() }
    }

    // Mostrar diálogo para reservas
    private fun mostrarDialogoReservar() {
        val dialogView = layoutInflater.inflate(R.layout.gestion_implementos, null)
        val spinner = dialogView.findViewById<Spinner>(R.id.spinnerImplementos)
        val btnFecha = dialogView.findViewById<Button>(R.id.btnSeleccionarFecha)
        val tvFecha = dialogView.findViewById<TextView>(R.id.tvFechaSeleccionada)
        val etProblema = dialogView.findViewById<EditText>(R.id.etProblema) // Este campo debe estar en el layout

        etProblema.visibility = View.GONE

        // Configurar Spinner
        val implementos = checkboxMap.keys.toList()
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, implementos)

        var fechaSeleccionada: String? = null
        btnFecha.setOnClickListener {
            val calendario = Calendar.getInstance()
            DatePickerDialog(
                this,
                { _, año, mes, día ->
                    fechaSeleccionada = "$día/${mes + 1}/$año"
                    tvFecha.text = "Fecha seleccionada: $fechaSeleccionada"
                },
                calendario.get(Calendar.YEAR),
                calendario.get(Calendar.MONTH),
                calendario.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        AlertDialog.Builder(this)
            .setTitle("Reservar Implemento")
            .setView(dialogView)
            .setPositiveButton("Reservar") { _, _ ->
                val implemento = spinner.selectedItem.toString()

                if (!fechaSeleccionada.isNullOrEmpty()) {
                    guardarReserva(implemento, fechaSeleccionada!!)
                } else {
                    Toast.makeText(this, "Por favor selecciona una fecha para la reserva.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }
    // Mostrar diálogo para mantenimiento
    private fun mostrarDialogoMantenimiento() {
        val dialogView = layoutInflater.inflate(R.layout.gestion_implementos, null)
        val spinner = dialogView.findViewById<Spinner>(R.id.spinnerImplementos)
        val etProblema = dialogView.findViewById<EditText>(R.id.etProblema) // Este campo debe estar visible solo para mantenimiento
        val btnFecha = dialogView.findViewById<Button>(R.id.btnSeleccionarFecha)
        val tvFecha = dialogView.findViewById<TextView>(R.id.tvFechaSeleccionada)

        etProblema.visibility = View.VISIBLE

        // Configurar Spinner
        val implementos = checkboxMap.keys.toList()
        spinner.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, implementos)

        var fechaSeleccionada: String? = null
        btnFecha.setOnClickListener {
            val calendario = Calendar.getInstance()
            DatePickerDialog(
                this,
                { _, año, mes, día ->
                    fechaSeleccionada = "$día/${mes + 1}/$año"
                    tvFecha.text = "Fecha seleccionada: $fechaSeleccionada"
                },
                calendario.get(Calendar.YEAR),
                calendario.get(Calendar.MONTH),
                calendario.get(Calendar.DAY_OF_MONTH)
            ).show()
        }

        AlertDialog.Builder(this)
            .setTitle("Gestionar Mantenimiento")
            .setView(dialogView)
            .setPositiveButton("Guardar") { _, _ ->
                val implemento = spinner.selectedItem.toString()
                val problema = etProblema.text.toString()

                if (!fechaSeleccionada.isNullOrEmpty() && problema.isNotEmpty()) {
                    guardarMantenimiento(implemento, problema, fechaSeleccionada!!)
                } else {
                    Toast.makeText(this, "Por favor completa todos los campos.", Toast.LENGTH_SHORT).show()
                }
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }


    // Guardar reserva en Firebase
    private fun guardarReserva(implemento: String, fecha: String) {
        val datos = mapOf(
            "implemento" to implemento,
            "fecha_reserva" to fecha,
            "estado" to false
        )

        db.collection("reservas")
            .document(implemento)
            .set(datos)
            .addOnSuccessListener {
                Toast.makeText(this, "Reserva guardada con éxito.", Toast.LENGTH_SHORT).show()
                actualizarEstado(implemento, fecha, false, "Reservado")
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error al guardar la reserva: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    // Guardar mantenimiento en Firebase
    private fun guardarMantenimiento(implemento: String, problema: String, fecha: String) {
        val datos = mapOf(
            "implemento" to implemento,
            "problema" to problema,
            "fecha_mantenimiento" to fecha,
            "estado" to false
        )

        db.collection("mantenimiento")
            .document(implemento)
            .set(datos)
            .addOnSuccessListener {
                Toast.makeText(this, "Mantenimiento guardado con éxito.", Toast.LENGTH_SHORT).show()
                actualizarEstado(implemento, fecha, false, "Mantenimiento: $problema")
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error al guardar: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    // Cargar estados desde Firebase
    private fun cargarEstados() {
        db.collection("reservas")
            .get()
            .addOnSuccessListener { reservas ->
                reservas.forEach { doc ->
                    val implemento = doc.getString("implemento") ?: return@forEach
                    val fecha = doc.getString("fecha_reserva") ?: ""
                    val estado = doc.getBoolean("estado") ?: true
                    actualizarEstado(implemento, fecha, estado, "Reservado")
                }
            }

        db.collection("mantenimiento")
            .get()
            .addOnSuccessListener { mantenimientos ->
                mantenimientos.forEach { doc ->
                    val implemento = doc.getString("implemento") ?: return@forEach
                    val fecha = doc.getString("fecha_mantenimiento") ?: ""
                    val problema = doc.getString("problema") ?: "Mantenimiento"
                    val estado = doc.getBoolean("estado") ?: true
                    actualizarEstado(implemento, fecha, estado, "Mantenimiento: $problema")
                }
            }
            .addOnFailureListener { e ->
                Toast.makeText(this, "Error al cargar estados: ${e.message}", Toast.LENGTH_SHORT).show()
            }
    }

    // Actualizar estado
    private fun actualizarEstado(implemento: String, fecha: String, estado: Boolean, estadoTexto: String) {
        checkboxMap[implemento]?.isEnabled = estado
        fechaTextViewMap[implemento]?.text = if (estado) "" else "$estadoTexto ($fecha)"
    }
}
